﻿<?php
session_start();
include_once("cabecalho.php");  
include_once("footer.php");  

?>

<html lang="pt-br">

<head>
    <meta http-equiv= "Content-Type" content= "text/html; charset=iso-8859-1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarbsCounter</title>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="stylehome.css"/>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.js">
</script>
</head>

<body>
</br>
</br>
</br>

<div class="container">

<h1> Artigos </h1>

<div class="artigos">

<article>
<center>
<p id="p1">O que é Diabetes?</p>
</br>

<a href="oquee1.php"> 
<img id="artigos" src="img/diabetes.jpg" alt="Dê o seu primeiro passo" height="180px" width="200px">
</a>
</center>

</article>

</div>

<div class="artigos">
<article>
<center>
<p id="p1">Diabetes: Entenda de uma vez sobre a doença</p>
</br>

<a href="video1.php"> 
<img id="artigos" src="img/download.png" alt="Dê o seu primeiro passo" height="180px" width="200px">
</a>
</center>

</article>

</div>
</div>
</div>

</br>
</br>
</br>
</br>
</br>
</br>
0abab5

</main>

</body>
</html>