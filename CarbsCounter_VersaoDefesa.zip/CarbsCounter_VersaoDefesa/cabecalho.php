﻿<div class="container-fluid">
<div class="row">
<div class="col-md-12 navbar">
<img id="logo" src='img/logo5.png' height = '115px' width='135px' class="logo navbar-brand text-white offset-md-2"/> 
<ul class="nav">
<li class="nav-item active"><a href="home.php" class="nav-link">Home</a></li>
<li class="nav-item"> <a href="artigos1.php" class="nav-link" target="_self"> Sou diabético, e agora? </a></li> 
<li class="nav-item"><a href="tabelax.php" class="nav-link" target="_self"> Tabela Nutricional</a></li>  
<li class="nav-item"><a href="sobrenos1.php" target="_self" class="nav-link">Sobre nós</a></li> 
<li class="nav-item"><a href="diario.php" target="_self" class="nav-link">Diário Glicêmico</a></li>
<li class="nav-item"><a href="usuario_info.php" target="_self" class="nav-link">Perfil</a></li>
<li class="nav-item"><a href="session_destroy.php" target="_self" class="nav-link">Sair do Sistema</a></li>

</ul>

</div>
</div>
</div>
