﻿<?php

include_once("cabecalho.php");  
include_once("footer.php");  

?>
<html lang="pt-br">

<head>
    <meta http-equiv= "Content-Type" content= "text/html; charset=iso-8859-1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarbsCounter</title>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="stylehome.css"/>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.js">
</script>
</head>

<body>

</br>
</br>
</br>

<div class="container">

<p id="p1"> 

Nós somos uma equipe formada por cinco pessoas, três estudantes e duas docentes do Centro Federal de Educação Tecnológica, em Leopoldina, Minas Gerais. Desenvolvemos esse projeto afim de facilitar a vida de pessoas portadoras de diabetes. Um membro de nosso projeto, vivencia a doença e as dificuldades de controlá-la. Com isso, a ideia de um sistema web que facilitaria a vida dos diabeticos, se tornou realidade. Para nos conhecer melhor, nos acompanhe nas redes sociais: @beatrizrdt, @bii4_trindade, @gabrielgailf, @nataliadamata e principalmente: @carbscounterbr. Nosso email para contato pessoal e demais dúvidas é: equipecarbscounter@gmail.com

</p>

</div>

</br>
</br>
</br>
</br>
</br>
</br>

</main>

</body>
</html>